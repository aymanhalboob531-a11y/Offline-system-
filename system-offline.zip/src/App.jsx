import { Routes, Route, Link } from "react-router-dom";
import Login from "./pages/Login.jsx";
import Home from "./pages/Home.jsx";
import InspectionEntry from "./pages/InspectionEntry.jsx";
import InspectionSummary from "./pages/InspectionSummary.jsx";
import Admin from "./pages/Admin.jsx";
import Report from "./pages/Report.jsx";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <header className="sticky top-0 z-40 backdrop-blur bg-slate-950/80 border-b border-white/10">
        <nav className="max-w-6xl mx-auto flex items-center gap-2 px-4 py-3 overflow-x-auto">
          <Link to="/" className="font-bold text-base mr-2 whitespace-nowrap">smis-web</Link>
          <div className="flex gap-1 ml-auto">
          <Link to="/login" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Login</Link>
          <Link to="/" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Home</Link>
          <Link to="/inspection/entry" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Inspection Entry</Link>
          <Link to="/inspection/summary" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Inspection Summary</Link>
          <Link to="/admin" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Admin Portal</Link>
          <Link to="/report" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Report</Link>
          </div>
        </nav>
      </header>
      <main className="flex-1">
        <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Home />} />
        <Route path="/inspection/entry" element={<InspectionEntry />} />
        <Route path="/inspection/summary" element={<InspectionSummary />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/report" element={<Report />} />
        </Routes>
      </main>
      <footer className="border-t border-white/10 py-4 text-center text-xs text-slate-500">
        © 2026 smis-web
      </footer>
    </div>
  );
}
