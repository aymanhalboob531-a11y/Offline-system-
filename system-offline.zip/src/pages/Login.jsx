/*  ──────────────────────────────────────────────────────────
    src/pages/Login.jsx
    تصميم صفحة تسجيل الدخول (Login) – كائن React
    ------------------------------------------------------------*/

import { useState } from 'react';
import './Login.css';                     // ملفات CSS منفصلة

export default function Login() {
  /*  -----------------------------
      الحالة (state) للمُدخلات
      ----------------------------- */
  const [fullName, setFullName]      = useState('');
  const [militaryId, setMilitaryId] = useState('');
  const [rank, setRank]             = useState('Private');
  const [alert, setAlert]           = useState('');

  /*  -----------------------------
      معالجة إرسال النموذج
      ----------------------------- */
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Payload
    const payload = { fullName, militaryId, rank };

    /*  -----------------------------
        إدخال المُتحَكِّم بنفس الجامعة لمنع مهام الـ CORS
        ----------------------------- */
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();

      if (!res.ok) {
        setAlert(data?.message || 'فشل في تسجيل الدخول');
        return;
      }

      // على سبيل المثال: إعادة توجيه للمسار الأساسي
      window.location.href = '/';
    } catch (err) {
      setAlert('خطأ في الشبكة. حاول مرة أخرى.');
      console.error(err);
    }
  };

  return (
    <div className="login-wrapper">
      <form className="login-box" onSubmit={handleSubmit} noValidate>
        <h2>تسجيل الدخول</h2>

        {/*  ----------  الاسم الكامل  ---------- */}
        <div className="field">
          <label htmlFor="fullName">الاسم الكامل</label>
          <input
            type="text"
            id="fullName"
            name="fullName"
            value={fullName}
            onChange={e => setFullName(e.target.value)}
            placeholder="الرجاء إدخال الاسم"
            required
          />
        </div>

        {/*  ----------  رقم الهوية العسكرية  ---------- */}
        <div className="field">
          <label htmlFor="militaryId">رقم الهوية العسكرية</label>
          <input
            type="text"
            id="militaryId"
            name="militaryId"
            value={militaryId}
            onChange={e => setMilitaryId(e.target.value)}
            placeholder="مثال: 123456"
            required
          />
        </div>

        {/*  ----------  الرتبة (Select)  ---------- */}
        <div className="field">
          <label htmlFor="rank">الرتبة</label>
          <select
            id="rank"
            name="rank"
            value={rank}
            onChange={e => setRank(e.target.value)}
          >
            <option value="Private">جندي</option>
            <option value="Corporal">مشرف</option>
            <option value="Sergeant">ضابط</option>
            <option value="Lieutenant">نقيب</option>
            <option value="Captain">رائد</option>
            <option value="Major">عميد</option>
            <option value="Colonel">رئيس</option>
            <option value="General">جنرال</option>
          </select>
        </div>

        {/*  ----------  زر الإرسال  ---------- */}
        <button type="submit" className="btn-submit">
          تسجيل الدخول
        </button>

        {/*  ----------  رسالة تحذيرية  ---------- */}
        {alert && (
          <div className="alert show">
            {alert}
          </div>
        )}
      </form>
    </div>
  );
}