import React from 'react';

export default function AdminPortal() {
  return (
    <div className="min-h-screen flex flex-col bg-[#2d353f] text-white font-sans">
      {/* Header */}
      <header className="bg-[#021f44] px-6 py-4 flex items-center justify-between shadow-md">
        <h1 className="text-2xl font-bold uppercase tracking-tight">
          ADMIN PORTAL
        </h1>
        <nav className="space-x-4">
          <a href="#" className="hover:text-[#64ff00] transition-colors">
            Settings
          </a>
          <a href="#" className="hover:text-[#64ff00] transition-colors">
            Logout
          </a>
        </nav>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 bg-[#021f44] flex flex-col py-6 px-4 space-y-4">
          <a
            href="#"
            className="text-lg font-medium hover:text-[#64ff00] transition-colors"
          >
            Dashboard
          </a>
          <a
            href="#"
            className="text-lg font-medium hover:text-[#64ff00] transition-colors"
          >
            Inspectors
          </a>
          <a
            href="#"
            className="text-lg font-medium hover:text-[#64ff00] transition-colors"
          >
            Committee
          </a>
          <a
            href="#"
            className="text-lg font-medium hover:text-[#64ff00] transition-colors"
          >
            Reports
          </a>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 overflow-y-auto">
          {/* Alert Example */}
          <div
            className="mb-6 p-4 rounded-lg bg-[#443c10] text-[#64ff00] flex items-center space-x-3 border-l-4 border-[#ffea00]"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6 flex-shrink-0"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M13 16h-1v-4h-1M12 22a10 10 0 110-20 10 10 0 010 20z"
              />
            </svg>
            <span>Inspection data updated successfully.</span>
          </div>

          {/* Responsive Grid Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Inspector Card */}
            <div className="bg-[#4a4a4a] rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4 uppercase">
                Inspectors
              </h2>
              <ul className="space-y-2">
                <li className="flex items-center justify-between">
                  <span>John Doe</span>
                  <span className="text-sm text-[#64ff00]">Active</span>
                </li>
                <li className="flex items-center justify-between">
                  <span>Jane Smith</span>
                  <span className="text-sm text-[#ff4444]">Pending</span>
                </li>
                <li className="flex items-center justify-between">
                  <span>Mike Johnson</span>
                  <span className="text-sm text-[#4ca1a3]">Inactive</span>
                </li>
              </ul>
            </div>

            {/* Committee Card */}
            <div className="bg-[#4a4a4a] rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4 uppercase">
                Committee
              </h2>
              <ul className="space-y-2">
                <li className="flex items-center justify-between">
                  <span>Finance</span>
                  <span className="text-sm text-[#64ff00]">Active</span>
                </li>
                <li className="flex items-center justify-between">
                  <span>Engineering</span>
                  <span className="text-sm text-[#64ff00]">Active</span>
                </li>
                <li className="flex items-center justify-between">
                  <span>HR</span>
                  <span className="text-sm text-[#ff4444]">Pending</span>
                </li>
              </ul>
            </div>

            {/* أي محتوى إضافي هنا */}
          </div>
        </main>
      </div>
    </div>
  );
}