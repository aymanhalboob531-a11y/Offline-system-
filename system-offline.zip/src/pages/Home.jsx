<!DOCTYPE html>
<html lang="ar">

<head>
  <meta charset="UTF-8">
  <title>Dashboard – Home</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      /* Colours */
      --primary: #021f44;
      --bg: #2a2e35;
      --alert: #e8f100;

      /* Fonts */
      --font-body: 'Inter', system-ui, sans-serif;
      --font-heading: 'Microsoft Sans Serif', system-ui, sans-serif;
    }

    /* Global reset & base styles */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    html, body { height: 100%; font-family: var(--font-body); background: var(--bg); color: #fff; }
    h1, h2, h3, h4, h5, h6 { font-family: var(--font-heading); text-transform: uppercase; }

    /* Layout */
    .app {
      display: grid;
      grid-template-columns: 25% 75%;
      height: 100vh;
    }

    /* Navigation Rail */
    .nav {
      background: var(--primary);
      padding: 1rem;
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    .nav a{
      color: #fff;
      text-decoration: none;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: .5rem;
      padding: .5rem .75rem;
      border-radius: .4rem;
    }
    .nav a:hover{ background: rgba(255,255,255,.1); }

    /* Workspace */
    .workspace {
      padding: 2rem;
      overflow-y: auto;
    }

    /* Alert example */
    .alert{
      background: var(--alert);
      color: var(--primary);
      font-weight: 600;
      padding: .75rem 1rem;
      border-radius: .3rem;
      margin-bottom: 1rem;
    }
  </style>
</head>

<body>
  <div class="app">

    <!-- Navigation Rail -->
    <nav class="nav">
      <a href="#">Dashboard</a>
      <a href="#">Reports</a>
      <a href="#">Analytics</a>
      <a href="#">Settings</a>
    </nav>

    <!-- Workspace -->
    <section class="workspace">
      <h1>Dashboard</h1>
      <div class="alert">New critical update is available!</div>

      <!-- Premium widgets go here -->
      <p>Welcome to your premium dashboard. Use the navigation rail to access all sections.</p>
    </section>

  </div>
</body>
</html>

export default function Home() { return null; }