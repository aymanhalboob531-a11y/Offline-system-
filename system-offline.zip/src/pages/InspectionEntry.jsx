export default function InspectionEntry() {
  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans">
      <div className="max-w-4xl mx-auto p-6">
        <h1 className="text-3xl font-bold text-yellow-400 mb-8">Inspection Entry</h1>

        <form className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="assetId" className="block text-sm font-medium text-gray-300 mb-1">Asset ID</label>
              <input
                type="text"
                id="assetId"
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-400"
                placeholder="Enter asset ID"
              />
            </div>

            <div>
              <label htmlFor="inspector" className="block text-sm font-medium text-gray-300 mb-1">Inspector</label>
              <input
                type="text"
                id="inspector"
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-400"
                placeholder="Enter inspector name"
              />
            </div>
          </div>

          <div>
            <label htmlFor="location" className="block text-sm font-medium text-gray-300 mb-1">Location</label>
            <input
              type="text"
              id="location"
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-400"
              placeholder="Enter location"
            />
          </div>

          <div>
            <label htmlFor="inspectionDate" className="block text-sm font-medium text-gray-300 mb-1">Inspection Date</label>
            <input
              type="date"
              id="inspectionDate"
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
          </div>

          <div>
            <label htmlFor="condition" className="block text-sm font-medium text-gray-300 mb-1">Condition</label>
            <select
              id="condition"
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-400"
            >
              <option value="">Select condition</option>
              <option value="excellent">Excellent</option>
              <option value="good">Good</option>
              <option value="fair">Fair</option>
              <option value="poor">Poor</option>
              <option value="critical">Critical</option>
            </select>
          </div>

          <div>
            <label htmlFor="notes" className="block text-sm font-medium text-gray-300 mb-1">Notes</label>
            <textarea
              id="notes"
              rows="4"
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-400"
              placeholder="Enter inspection notes"
            ></textarea>
          </div>

          <div className="flex justify-end space-x-4">
            <button
              type="button"
              className="px-4 py-2 bg-gray-700 text-gray-100 rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-yellow-500 text-gray-900 rounded-md hover:bg-yellow-400 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            >
              Submit Inspection
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}