// server/api.js
const express = require('express');
const router = express.Router();

// --------------------
// Mock data
// --------------------
const users = [
  {
    id: 1,
    fullName: 'Ahmed Al‑Fares',
    militaryId: 'MF-001',
    rank: 'Lieutenant',
    role: 'Inspector',
  },
  {
    id: 2,
    fullName: 'Sara Kamel',
    militaryId: 'MF-002',
    rank: 'Sergeant',
    role: 'Supervisor',
  },
  {
    id: 3,
    fullName: 'Omar Hassan',
    militaryId: 'MF-003',
    rank: 'Corporal',
    role: 'Technician',
  },
];

const inspections = [
  {
    id: 1,
    assetNumber: 'AS-001',
    assetType: 'Vehicle',
    device: 'Engine',
    serialNumber: 'SN-01',
    quantity: 2,
    status: 'Passed',
    notes: 'All good',
    timestamp: new Date('2024-04-01T10:30:00Z'),
  },
  {
    id: 2,
    assetNumber: 'AS-002',
    assetType: 'Weapon',
    device: 'Scope',
    serialNumber: 'SN-02',
    quantity: 1,
    status: 'Failed',
    notes: 'Needs repair',
    timestamp: new Date('2024-04-03T14:15:00Z'),
  },
];

// --------------------
// Utility helpers
// --------------------
const generateToken = (username) => Buffer.from(username).toString('base64');
const authenticate = (req, res, next) => {
  const authHeader = req.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid token' });
  }
  const token = authHeader.slice(7);
  const username = Buffer.from(token, 'base64').toString();
  const user = users.find(u => u.fullName === username);
  if (!user) return res.status(401).json({ error: 'Invalid token' });
  req.user = user;
  next();
};

// --------------------
// Routes
// --------------------

// GET /api/users
router.get('/api/users', authenticate, (req, res) => {
  res.json(users);
});

// POST /api/auth/login
router.post('/api/auth/login', (req, res) => {
  const { username } = req.body;
  if (!username) return res.status(400).json({ error: 'username required' });

  const user = users.find(u => u.fullName === username);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });

  const token = generateToken(username);
  res.json({ token });
});

// GET /api/inspections
router.get('/api/inspections', authenticate, (req, res) => {
  const totalEntries = inspections.length;
  const totalQuantity = inspections.reduce((sum, e) => sum + e.quantity, 0);
  const latestTimestamp = inspections.reduce(
    (latest, e) => (e.timestamp > latest ? e.timestamp : latest),
    inspections[0]?.timestamp || null
  );
  res.json({
    totalEntries,
    totalQuantity,
    latestInspection: latestTimestamp,
    inspections,
  });
});

// POST /api/inspections/entry
router.post('/api/inspections/entry', authenticate, (req, res) => {
  const {
    assetNumber,
    assetType,
    device,
    serialNumber,
    quantity,
    status,
    notes,
  } = req.body;

  if (!assetNumber || !assetType || !device || !serialNumber || !quantity || !status) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const newEntry = {
    id: inspections.length ? inspections[inspections.length - 1].id + 1 : 1,
    assetNumber,
    assetType,
    device,
    serialNumber,
    quantity: Number(quantity),
    status,
    notes: notes || '',
    timestamp: new Date(),
  };
  inspections.push(newEntry);
  res.status(201).json(newEntry);
});

module.exports = router;