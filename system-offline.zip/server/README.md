# Backend

Generated stub for smis-web. Run with `node server/index.js` after wiring an Express server.